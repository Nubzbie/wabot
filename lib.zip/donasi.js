exports.donasi = (id, BotName, corohelp, tampilTanggal, tampilWaktu, instagram, whatsapp, kapanbotaktif, grupch1, grupch2) => {
	return `🤜{ *MENU DONASI ${BotName}* }🤛
  
  
TERIMA KASIH
*${id.split("@s.whatsapp.net")[0]}*
TELAH MEMBUKA MENU DONASI
 🙇🏼🙇🏼🙇🏼🙇🏼🙇🏼


💁🏼‍♂️ *${tampilTanggal}* ⚡️
💁🏼 *${tampilWaktu}* ⚡️
(Waktu Server)

KALIAN BISA DONASI MENGGUNAKAN
   
🛡 *PULSA*: 081213477896
🛡 *OVO*: 081213477896
🛡 *DANA* : 081213477896
🛡 *TRAKTEER*: https://trakteer.id/aditiaalfiansyah

⬇️⬇️⬇️⬇️⬇️⬇️⬇️⬇️⬇️⬇️⬇️
 🏍🏍🏍🏍🏍🏍🏍🏍🏍🏍🏍
*Follow Me On Instagram*
${instagram}

👾whatsapp : ${whatsapp}

`
}
