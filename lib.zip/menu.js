exports.menu = (id, BotName, corohelp, tampilTanggal, tampilWaktu, instagram, whatsapp, kapanbotaktif, grupch1, grupch2) => {
	return `🚀 *${BotName}* 🚀
  
*Hai kak* *${id.split("@s.whatsapp.net")[0]}* 

Sebelum menggunakan bot ini ada baiknya kalian melihat menu *!info* dan *!donasi* 😎😎😎

😉 *Support Me On !donasi*

💁🏼‍♂️ *${tampilTanggal}* ⚡️
💁🏼 *${tampilWaktu}* ⚡️
(Waktu Server)

🌏🌏KUMPULAN COMMAND ${BotName}:
 
⚽️ *FUN* ⚽️

💨 _*!ocr*_
_${BotName}_🛸 untuk melihat text dari gambar yang kamu kirimkan

Pengggunaan : Kirimkan gambarmu dengan caption !ocr

💨 _*!pantun*_
_${BotName}_🛸 akan mengirimkanmu pantun secara random

💨 _*!animepict*_
_${BotName}_🛸akan mengirimkanmu gambar anime secara random

💨 _*!sticker*_
_${BotName}_🛸 akan membuatkan sticker dari gambar yang kamu kirimkan

Pengggunaan : Kirimkan gambarmu dengan caption !sticker

💨 _*!nulis <teks>*_
_${BotName}_🛸 akan menuliskan teks yang kamu kirimkan

Contoh: !nulis pasti nana bangka dadang ko bang jamping jamping 

💨 _*!quotes*_
_${BotName}_🛸 akan mencarikanmu quotes secara random

💨 _*!pict <cewek/cowok>*_
_${BotName}_🛸 akan mengirimkanmu gambar cewek/cowok secara random
Contoh: !pict cowok

💨 _*!animepict*_
_${BotName}_🛸 akan mengirimkanmu gambar anime secara random

💨 _*!say <teks>*_
_${BotName}_🛸 akan mengirimkan kembali teks yang kamu kirimkan
Contoh: !say buset bang

💨 _*!lirik*_ <penyanyi-judul lagu>
_${BotName}_🛸 akan mengirimkanmu lirik lagu yang kamu inginkan
contoh : !lirik Lisa-Gurenge

💨 _*!alay*_ <teks>
_${BotName}_🛸 akan mengubah teks yang kamu kirimkan menjadi alay
contoh : !alay ampun bang jago


🎆 *ISLAM* 🎆

💨 _*!sholat <daerah>*_
_${BotName}_🛸 akan mengirimkan jadwal sholat sesuai dengan daerah yang kamu kirimkan

Penggunaan 	: !sholat + daerah kamu
Contoh		: !sholat Bekasi

💨 _*!quran*_
_${BotName}_🛸 akan mengirimkanmu ayat Al-Quran secara random

📥 *DOWNLOADER* 📥

💨 _*!yt <link>*_
_${BotName}_🛸 akan mendownloadkan video youtube sesuai dengan link yang kamu kirimkan.
Contoh: !yt https://youtu.be/linkamu

💨 _*!ytmp3 <link>*_
_${BotName}_🛸 akan mengubah video youtube menjadi audio sesuai dengan link yang kamu kirimkan

Contoh: !ytmp3 https://youtu.be/linkamu

💨 _*!ig <link>*_
_${BotName}_🛸 akan mengirimkanmu foto/video dari link ig yang kamu kirimkan

Contoh: !ig https://instagram.com/linkamu

💨 _*!fb <link>*_ //ERROR//
_${BotName}_🛸 akan mengirimkanmu foto/video dari link ig yang kamu kirimkan

Contoh: !fb https://facebook.com/linkamu

💨 _*!twt <link>*_
_${BotName}_🛸 akan mengirimkanmu foto/video dari link ig yang kamu kirimkan

Contoh: !twt https://twitter.com/linkamu

💨 _*!tiktok <link>*_

_${BotName}_ akan mengirimkanmu video dari link tiktok yang kamu kirimkan

🎏 *EDUKASI* 🎏

💨 _*!wikia <yang kamu cari>*_
_${BotName}_🛸 akan mencarikan yang kamu mau di wikipedia

Contoh: !wikia Adolf Hitler

💨 _*!covid*_
_${BotName}_🛸 akan menampilkan data tentang COVID-19 di Indonesia

🎎 *PRIMBON* 🎎

💨 _*!nama <namakamu>*_
_${BotName}_🛸 akan mencarikan apa arti dari nama kamu

Contoh : !nama Adit

💨 _*!pasangan <namamu & pasangan>*_
_${BotName}_🛸 akan mencarikan kecocokan antara kamu dan pasanganmu

Contoh : !pasangan covad & covid

⬇️⬇️⬇️⬇️⬇️⬇️⬇️⬇️⬇️⬇️⬇️
 🏍🏍🏍🏍🏍🏍🏍🏍🏍🏍🏍
🍭 *Follow Me On Instagram*
${instagram}

👾Whatsapp : ${whatsapp}

🏚SELALU GUNAKAN MASKER SAAT KELUAR!🏚
🏚SEMOGA SEHAT SELALU!🏚
`
}
