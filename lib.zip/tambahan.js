module.exports = {
	halo: "HALO JUGA ZEYENKK* \n\nketik *!menu* untuk menampilkan semua fitur yang ada \r\n\r\n \n \r",
	hai: "HAI JUGAA!*\n\n ketik *!menu* untuk menampilkan semua fitur yang ada \r\n\r\n \n \r",
	ass: "WAALAIKUMSALAM*\n\n ketik *!menu* untuk menampilkan semua fitur yang ada \r\n\r\n \n \r",
	bro: "EUUUYYYY!!!* \n\nketik *!menu* untuk menampilkan semua fitur yang ada \r\n\r\n \n \r",
	p: "pa pe pa pe pap pap*\n\n ketik *!menu* untuk menampilkan semua fitur yang ada \r\n\r\n \n \r",
	test: "*satu dua dicoba*\n\n ketik *!menu* untuk menampilkan semua fitur yang ada \r\n\r\n \n \r",
	sbr: "SABAR BOII LAGI DICARIIN",
}