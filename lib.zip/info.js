exports.info = (id, BotName, corohelp, tampilTanggal, tampilWaktu, instagram, whatsapp, kapanbotaktif, grupch1, grupch2) => {
	return `🧑‍🚀 ${BotName} 🧑‍🚀
  
Hai kak *${id.split("@s.whatsapp.net")[0]}*
"
Ketik *!info* untuk melihat deskripsi bot

INFO BOT! :
AUTHOR: Isshiki gans


INFO LAIN! :

APAKAH AKU PELARIANMU SAJA!!

bot aktif selama : ${kapanbotaktif}
JANGAN LUPA FOLLOW instagram
 ${instagram}

 👾whatsapp : ${whatsapp}`
}
